package ru.tu3.journal;

import java.util.ArrayList;
import java.util.List;

/** Описание страниц журнала: какие поля есть на каждой странице формы ТУ-3ВЦУ. */
public class Tu3Pages {
    public static class Page {
        public final String title;
        public final int cols;
        public final int maxLen;
        public final List<String> labels;

        Page(String title, int cols, int maxLen, List<String> labels) {
            this.title = title;
            this.cols = cols;
            this.maxLen = maxLen;
            this.labels = labels;
        }
    }

    public static final List<Page> PAGES = build();

    public static String key(int page, int index) {
        return "p" + page + "_" + index;
    }

    private static void crew(List<String> l, String prefix) {
        l.add(prefix + "Табельный №");
        l.add(prefix + "Фамилия И.О.");
        l.add(prefix + "Должн./призн.");
        l.add(prefix + "Явка на работу");
        l.add(prefix + "Начало приёмки ТПС");
        l.add(prefix + "КП депо: при выходе");
        l.add(prefix + "КП депо: при заходе");
        l.add(prefix + "Окончание сдачи ТПС");
        l.add(prefix + "Окончание работы");
        l.add(prefix + "Обед: начало");
        l.add(prefix + "Обед: окончание");
    }

    private static List<Page> build() {
        List<Page> pages = new ArrayList<Page>();

        // Страница 1: шапка + машинист
        List<String> p1 = new ArrayList<String>();
        p1.add("Маршрут машиниста №");
        p1.add("Дата (число, месяц, год)");
        p1.add("Приписка бригады (ж.д.)");
        p1.add("Депо приписки бригады");
        p1.add("Учётный №");
        p1.add("Машинист: Фамилия И.О.");
        crew(p1, "Маш.: ");
        // Фамилия машиниста уже есть в шапке — убираем дубль
        p1.remove(p1.indexOf("Маш.: Фамилия И.О."));
        pages.add(new Page("Раздел 1. Шапка и машинист", 3, 64, p1));

        // Страница 2: помощники, резервная бригада
        List<String> p2 = new ArrayList<String>();
        crew(p2, "Пом.: ");
        crew(p2, "3-й чл.: ");
        p2.add("Резерв. бригада (пассажиром)");
        p2.add("Явка (резервной бригады)");
        pages.add(new Page("Раздел 1. Помощник, третий член бригады, резервная бригада", 4, 64, p2));

        // Страница 3: раздел 2 — ТПС и топливо
        List<String> p3 = new ArrayList<String>();
        for (int s = 1; s <= 3; s++) {
            String pr = "Секц." + s + ": ";
            p3.add(pr + "Оконч. сдачи пред. бригадой");
            p3.add(pr + "Составность ТПС");
            p3.add(pr + "Код");
            p3.add(pr + "Принято при постановке в депо");
            p3.add(pr + "Топливо: счётчик при приёмке");
            p3.add(pr + "Топливо: счётчик при сдаче");
            p3.add(pr + "Счётчик 2: при приёмке");
            p3.add(pr + "Счётчик 2: при сдаче");
        }
        pages.add(new Page("Раздел 2. Состав и оборудование ТПС, расход топлива/электроэнергии", 4, 64, p3));

        // Страница 4: разделы 3 и 4
        List<String> p4 = new ArrayList<String>();
        for (int i = 1; i <= 3; i++) {
            p4.add("Р3 №" + i + ": ТПС по СМЕ/двойн. тяга");
            p4.add("Р3 №" + i + ": окончание сдачи");
        }
        p4.add("Р4: Плотность топлива");
        p4.add("Р4: Единицы (л / кг)");
        p4.add("Р4: Марка масла");
        p4.add("Р4: Снято топлива, № акта");
        p4.add("Р4: Снято масла, № акта");
        pages.add(new Page("Раздел 3. ТПС по СМЕ / двойной тяге; Раздел 4. Экипировка, снятие топлива и масла", 3, 64, p4));

        // Страница 5: замечания
        List<String> p5 = new ArrayList<String>();
        for (int i = 1; i <= 7; i++) p5.add("Замечание " + i);
        pages.add(new Page("Раздел 5. Замечания", 1, 120, p5));

        return pages;
    }
}
