package ru.tu3.journal;

import net.minecraft.util.EnumHand;

public class CommonProxy {
    public void openJournal(EnumHand hand) {
    }
}
