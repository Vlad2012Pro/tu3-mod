package ru.tu3.journal;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = Tu3Mod.MODID, name = "Журнал ТУ-3", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
@Mod.EventBusSubscriber(modid = Tu3Mod.MODID)
public class Tu3Mod {
    public static final String MODID = "tu3journal";

    @SidedProxy(clientSide = "ru.tu3.journal.ClientProxy", serverSide = "ru.tu3.journal.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper NET;
    public static Item JOURNAL;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        NET = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        NET.registerMessage(PacketSave.Handler.class, PacketSave.class, 0, Side.SERVER);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        JOURNAL = new ItemJournal();
        event.getRegistry().register(JOURNAL);
    }
}
