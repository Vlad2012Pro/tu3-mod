package ru.tu3.journal;

import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {
    @Override
    public void openJournal(EnumHand hand) {
        Minecraft mc = Minecraft.getMinecraft();
        ItemStack stack = mc.player.getHeldItem(hand);
        mc.displayGuiScreen(new GuiTu3(hand, stack));
    }
}
