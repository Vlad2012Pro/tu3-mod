package ru.tu3.journal;

import java.util.List;
import javax.annotation.Nullable;

import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ItemJournal extends Item {
    public ItemJournal() {
        setRegistryName(Tu3Mod.MODID, "tu3_journal");
        setUnlocalizedName(Tu3Mod.MODID + ".tu3_journal");
        setMaxStackSize(1);
        setCreativeTab(CreativeTabs.MISC);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);
        if (world.isRemote) {
            Tu3Mod.proxy.openJournal(hand);
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    @SideOnly(Side.CLIENT)
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        NBTTagCompound tag = stack.getTagCompound();
        if (tag != null && tag.hasKey("Tu3", 10)) {
            NBTTagCompound d = tag.getCompoundTag("Tu3");
            String route = d.getString(Tu3Pages.key(0, 0));
            String date = d.getString(Tu3Pages.key(0, 1));
            String name = d.getString(Tu3Pages.key(0, 5));
            if (!route.isEmpty()) tooltip.add(TextFormatting.GRAY + "Маршрут №" + route);
            if (!date.isEmpty()) tooltip.add(TextFormatting.GRAY + "Дата: " + date);
            if (!name.isEmpty()) tooltip.add(TextFormatting.GRAY + "Машинист: " + name);
        } else {
            tooltip.add(TextFormatting.GRAY + "ПКМ — открыть и заполнить");
        }
    }
}
