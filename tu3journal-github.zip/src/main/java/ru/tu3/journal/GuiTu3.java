package ru.tu3.journal;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public class GuiTu3 extends GuiScreen {
    private final EnumHand hand;
    private final NBTTagCompound data;
    private final List<GuiTextField> fields = new ArrayList<GuiTextField>();
    private int page = 0;

    public GuiTu3(EnumHand hand, ItemStack stack) {
        this.hand = hand;
        NBTTagCompound tag = stack.getTagCompound();
        if (tag != null && tag.hasKey("Tu3", 10)) {
            this.data = tag.getCompoundTag("Tu3").copy();
        } else {
            this.data = new NBTTagCompound();
        }
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        buttonList.clear();
        int by = height - 28;
        buttonList.add(new GuiButton(0, width / 2 - 150, by, 90, 20, "< Назад"));
        buttonList.add(new GuiButton(1, width / 2 + 60, by, 90, 20, "Далее >"));
        buttonList.add(new GuiButton(2, width / 2 - 45, by, 90, 20, "Готово"));
        buildFields();
    }

    private void buildFields() {
        fields.clear();
        Tu3Pages.Page p = Tu3Pages.PAGES.get(page);
        int n = p.labels.size();
        int rows = (n + p.cols - 1) / p.cols;
        int left = 20, top = 54;
        int rowH = Math.min(36, (height - top - 38) / rows);
        int cellW = (width - 2 * left) / p.cols;
        for (int i = 0; i < n; i++) {
            int col = i % p.cols;
            int row = i / p.cols;
            int fw = Math.min(cellW - 8, 420);
            GuiTextField f = new GuiTextField(100 + i, fontRenderer,
                    left + col * cellW, top + row * rowH + 11, fw, 14);
            f.setMaxStringLength(p.maxLen);
            f.setText(data.getString(Tu3Pages.key(page, i)));
            fields.add(f);
        }
        if (!fields.isEmpty()) fields.get(0).setFocused(true);
        buttonList.get(0).enabled = page > 0;
        buttonList.get(1).enabled = page < Tu3Pages.PAGES.size() - 1;
    }

    private void collect() {
        for (int i = 0; i < fields.size(); i++) {
            data.setString(Tu3Pages.key(page, i), fields.get(i).getText());
        }
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id == 0 && page > 0) {
            collect();
            page--;
            buildFields();
        } else if (b.id == 1 && page < Tu3Pages.PAGES.size() - 1) {
            collect();
            page++;
            buildFields();
        } else if (b.id == 2) {
            mc.displayGuiScreen(null);
        }
    }

    private void moveFocus(int dir) {
        if (fields.isEmpty()) return;
        int cur = -1;
        for (int i = 0; i < fields.size(); i++) {
            if (fields.get(i).isFocused()) cur = i;
            fields.get(i).setFocused(false);
        }
        int next = (cur + dir + fields.size()) % fields.size();
        fields.get(next).setFocused(true);
    }

    @Override
    protected void keyTyped(char c, int code) throws IOException {
        if (code == Keyboard.KEY_ESCAPE) {
            super.keyTyped(c, code);
            return;
        }
        if (code == Keyboard.KEY_TAB) {
            moveFocus(isShiftKeyDown() ? -1 : 1);
            return;
        }
        if (code == Keyboard.KEY_RETURN || code == Keyboard.KEY_NUMPADENTER) {
            moveFocus(1);
            return;
        }
        for (GuiTextField f : fields) {
            if (f.isFocused()) {
                f.textboxKeyTyped(c, code);
                return;
            }
        }
    }

    @Override
    protected void mouseClicked(int x, int y, int btn) throws IOException {
        super.mouseClicked(x, y, btn);
        for (GuiTextField f : fields) {
            f.mouseClicked(x, y, btn);
        }
    }

    @Override
    public void updateScreen() {
        for (GuiTextField f : fields) f.updateCursorCounter();
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawRect(10, 10, width - 10, height - 10, 0xFFEDE3C4);
        drawRect(10, 10, width - 10, 12, 0xFF3A3A3A);
        drawRect(10, height - 12, width - 10, height - 10, 0xFF3A3A3A);
        drawRect(10, 10, 12, height - 10, 0xFF3A3A3A);
        drawRect(width - 12, 10, width - 10, height - 10, 0xFF3A3A3A);

        Tu3Pages.Page p = Tu3Pages.PAGES.get(page);
        fontRenderer.drawString("Форма ТУ-3ВЦУ — МАРШРУТ МАШИНИСТА", 20, 16, 0x222222);
        String title = p.title + "   [" + (page + 1) + "/" + Tu3Pages.PAGES.size() + "]";
        fontRenderer.drawString(fontRenderer.trimStringToWidth(title, width - 40), 20, 32, 0x7A1F1F);

        for (int i = 0; i < fields.size(); i++) {
            GuiTextField f = fields.get(i);
            String label = fontRenderer.trimStringToWidth(p.labels.get(i), f.width);
            fontRenderer.drawString(label, f.x, f.y - 10, 0x333333);
            f.drawTextBox();
        }
        super.drawScreen(mx, my, pt);
    }

    @Override
    public void onGuiClosed() {
        collect();
        Keyboard.enableRepeatEvents(false);
        Tu3Mod.NET.sendToServer(new PacketSave(hand, data));
    }
}
