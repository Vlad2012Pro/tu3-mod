package ru.tu3.journal;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketSave implements IMessage {
    public int hand;
    public NBTTagCompound data;

    public PacketSave() {
    }

    public PacketSave(EnumHand h, NBTTagCompound data) {
        this.hand = h == EnumHand.OFF_HAND ? 1 : 0;
        this.data = data;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        hand = buf.readByte();
        data = ByteBufUtils.readTag(buf);
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeByte(hand);
        ByteBufUtils.writeTag(buf, data);
    }

    public static class Handler implements IMessageHandler<PacketSave, IMessage> {
        @Override
        public IMessage onMessage(final PacketSave msg, final MessageContext ctx) {
            final EntityPlayerMP player = ctx.getServerHandler().player;
            player.getServerWorld().addScheduledTask(new Runnable() {
                @Override
                public void run() {
                    if (msg.data == null) return;
                    EnumHand h = msg.hand == 1 ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND;
                    ItemStack stack = player.getHeldItem(h);
                    if (!(stack.getItem() instanceof ItemJournal)) return;

                    NBTTagCompound clean = new NBTTagCompound();
                    int n = 0;
                    for (String k : msg.data.getKeySet()) {
                        if (n >= 256) break;
                        if (!k.matches("p\\d_\\d{1,2}")) continue;
                        if (msg.data.getTagId(k) != 8) continue;
                        String v = msg.data.getString(k);
                        if (v.length() > 200) v = v.substring(0, 200);
                        clean.setString(k, v);
                        n++;
                    }
                    stack.setTagInfo("Tu3", clean);
                }
            });
            return null;
        }
    }
}
